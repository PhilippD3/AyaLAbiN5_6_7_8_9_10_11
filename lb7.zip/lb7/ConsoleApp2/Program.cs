﻿using lb7;
using System;
using System.IO;
using System.Reflection;
using System.Xml;

namespace GenerateClassDiagramXml
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFrom("lb7.dll");
            XmlWriterSettings settings = new XmlWriterSettings { Indent = true };
            XmlWriter writer = XmlWriter.Create("ClassDiagram.xml", settings);


            writer.WriteStartDocument();
            writer.WriteStartElement("ClassDiagram");


            foreach (Type type in assembly.GetTypes())
            {
   
                CommentAttribute commentAttribute = (CommentAttribute)Attribute.GetCustomAttribute(type, typeof(CommentAttribute));

       
                writer.WriteStartElement("Class");
                writer.WriteAttributeString("Name", type.Name);

         
                if (commentAttribute != null)
                {
                    writer.WriteStartElement("Comment");
                    writer.WriteString(commentAttribute.Comment);
                    writer.WriteEndElement();
                }

    
                foreach (PropertyInfo property in type.GetProperties())
                {
                    writer.WriteStartElement("Property");
                    writer.WriteAttributeString("Name", property.Name);
                    writer.WriteAttributeString("Type", property.PropertyType.Name);
                    writer.WriteEndElement();
                }

                foreach (MethodInfo method in type.GetMethods())
                {
                    writer.WriteStartElement("Method");
                    writer.WriteAttributeString("Name", method.Name);
                    writer.WriteEndElement();
                }

                writer.WriteEndElement(); 
            }

            writer.WriteEndElement(); 
            writer.WriteEndDocument();
            writer.Close();
        }
    }
}