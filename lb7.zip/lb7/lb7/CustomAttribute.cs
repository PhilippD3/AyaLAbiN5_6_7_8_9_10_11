﻿using System;

namespace lb7
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public class CustomAttribute : Attribute
    {
        public string Description { get; set; }
        public int Age { get; set; }

        public CustomAttribute(string description, int age)
        {
            Description = description;
            Age = age;
        }
    }
}