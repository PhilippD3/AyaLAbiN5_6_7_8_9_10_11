﻿using System;
using System.Collections.Generic;

namespace lb7
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class CommentAttribute : Attribute
    {
        public string Comment { get; set; }

        public CommentAttribute(string comment)
        {
            Comment = comment;
        }
    }
    public enum eClassificationAnimal
    {
        Herbivores,
        Carnivores,
        Omnivores
    }
    public enum eFavoriteFood
    {
        Meat,
        Plants,
        Everyrhing
    }
    [Comment("Базовый класс для всех животных")]
    public abstract class Animal
    {
        public eClassificationAnimal Classification { get; set; }
        public string Country { get; set; }
        public bool HideFromOtherAnimals { get; set; }
        public string Name { get; set; }
        public string WhatAnimal { get; set; }

        public Animal(string country, bool hideFromOtherAnimals, string name, string whatAnimal)
        {
            Country = country;
            HideFromOtherAnimals = hideFromOtherAnimals;
            Name = name;
            WhatAnimal = whatAnimal;
        }


        public void Deconstruct(out string country, out bool hideFromOtherAnimals, out string name, out string whatAnimal)
        {
            country = Country;
            hideFromOtherAnimals = HideFromOtherAnimals;
            name = Name;
            whatAnimal = WhatAnimal;
        }

        public virtual string GetClasificationAnimal()
        {
            return "Животное";
        }

        public virtual string GetFavoriteFood()
        {
            return "Трава";
        }

        public virtual string SayHello()
        {
            return "Привет!";
        }
    }
    [Comment("Базовый класс для коровы")]
    [CustomAttribute("Это корова", 5)]
    public class Cow : Animal
    {
        public Cow(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Корова")
        {
        }


        public override string GetFavoriteFood()
        {
            return "Трава";
        }

        public override string SayHello()
        {
            return "Мууу!";
        }
    }

    [Comment("Базовый класс для всех льва")]
    [CustomAttribute("Это лев", 5)]
    public class Lion : Animal
    {
        public Lion(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Лев")
        {
        }

        public override string GetFavoriteFood()
        {
            return "Мясо";
        }

        public override string SayHello()
        {
            return "Рррр!";
        }
    }
    [Comment("Базовый класс для свиньи ")]
    [CustomAttribute("Это свинья", 5)]
    public class Pig : Animal
    {
        public Pig(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Свинья")
        {
        }


        public override string GetFavoriteFood()
        {
            return "Корм";
        }

        public override string SayHello()
        {
            return "Хрю-хрю!";
        }
    }

    
}