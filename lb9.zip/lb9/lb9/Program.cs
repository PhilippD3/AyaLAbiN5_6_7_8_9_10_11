﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace StockPriceCalculator
{
    class Program
    {
   
        static async Task Main(string[] args)
        {
            List<string> tickers = File.ReadAllLines("ticker.txt").ToList();

            List<Task> tasks = new List<Task>();
            foreach (string ticker in tickers)
            {
                tasks.Add(CalculateAveragePriceAsync(ticker));
                System.Threading.Thread.Sleep(50);
            }

            await Task.WhenAll(tasks);

            Console.WriteLine("Средние цены акций рассчитаны и записаны в файл average_prices.txt.");
        }

        private static async Task CalculateAveragePriceAsync(string ticker)
        {
            using (HttpClient client = new HttpClient())
            {
                string url = $"https://api.marketdata.app/v1/stocks/candles/D/{ticker}/?from=2023-10-09&to=2024-10-09&token=bTZxYnROeWN3bEQzTVJOYzQ5REVNZzJVQ3FFZDBwbS1hZWsweHp3R2wxcz0";

            
                HttpResponseMessage response = await client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    dynamic responseObject = Newtonsoft.Json.JsonConvert.DeserializeObject(responseContent);

                    List<long> timestamps = responseObject.t.ToObject<List<long>>();
                    List<double> highs = responseObject.h.ToObject<List<double>>();
                    List<double> lows = responseObject.l.ToObject<List<double>>();

                    double averagePrice = 0;
                    for (int i = 0; i < timestamps.Count; i++)
                    {
                        averagePrice += (highs[i] + lows[i]) / 2;
                    }
                    averagePrice /= timestamps.Count;

                    await WriteToFileAsync(ticker, averagePrice);
                }
                
            }
        }

        private static async Task WriteToFileAsync(string ticker, double averagePrice)
        {
            using (StreamWriter writer = new StreamWriter("average_prices.txt", true))
            {
                await writer.WriteLineAsync($"{ticker}:{averagePrice}");
                Console.WriteLine($"{ticker}: {averagePrice}");
            }
        }
    }
}