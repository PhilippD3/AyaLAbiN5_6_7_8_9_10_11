﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Xml.Linq;
using Newtonsoft.Json;

public struct Weather
{
    public string Country { get; set; }
    public string Name { get; set; }
    public float Temp { get; set; }
    public string Description { get; set; }

    public Weather(string country, string name, float temp, string description)
    {
        Country = country;
        Name = name;
        Temp = temp;
        Description = description;
    }
    public override string ToString()
    {
        return $"Страна: {Country}, название местности: {Name}, температура воздуха: {Temp}°C, описание погоды: {Description}";
    }

}

class Program
{
    private static readonly HttpClient client = new HttpClient();
    private const string apiKey = "c0bca192b2e8c99548078dfb57a5150c";

    static async Task Main(string[] args)
    {
        var weathers = new List<Weather>();
        var random = new Random();

        while (weathers.Count < 50)
        {
            double lat = random.NextDouble() * 180 - 90;
            double lon = random.NextDouble() * 360 - 180;

            var weather = await GetWeatherAsync(lat, lon);
            if (weather != null)
            {
                weathers.Add(weather.Value);
            }
        }

        Console.WriteLine("All collected weather data:");
        foreach (var w in weathers)
        {
            Console.WriteLine(w.ToString());
        }

        var maxTempCountry = weathers.OrderByDescending(w => w.Temp).First();
        var minTempCountry = weathers.OrderBy(w => w.Temp).First();
        var averageTemp = weathers.Average(w => w.Temp);
        var countryCount = weathers.Select(w => w.Country).Distinct().Count();
        var specificDescription = weathers.First(w =>
            w.Description == "clear sky" ||
            w.Description == "rain" ||
            w.Description == "few clouds");

        Console.WriteLine($"Страна с максимальной температурой: {maxTempCountry.Country} ({maxTempCountry.Temp}°C)");
        Console.WriteLine($"Страна с минимальной температурой: {minTempCountry.Country} ({minTempCountry.Temp}°C)");
        Console.WriteLine($"Средняя температура в мире: {averageTemp}°C");
        Console.WriteLine($"Количество стран в коллекции: {countryCount}");
        if (specificDescription.Name != null)
        {
            Console.WriteLine($"Первая найденная страна и местность, в которой Description принимает значение:clear sky,rain,few clouds: {specificDescription.Country}, {specificDescription.Name}");
        }
        else
        {
            Console.WriteLine("Не найдено местностей с описанием 'clear sky', 'rain' или 'few clouds'.");
        }
    }

    private static async Task<Weather?> GetWeatherAsync(double lat, double lon)
    {
        var response = await client.GetStringAsync($"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&appid={apiKey}");
        dynamic json = JsonConvert.DeserializeObject(response);

        if (json.sys.country != null)
        {
            return new Weather
            {
                Country = json.sys.country,
                Name = json.name,
                Temp = json.main.temp,
                Description = json.weather[0].description
            };
        }
        return null;
    }
}
