﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace WindowsForms
{
    public struct Weather
    {
        public string Country { get; set; }
        public string Name { get; set; }
        public float Temp { get; set; }
        public string Description { get; set; }

        public Weather(string country, string name, float temp, string description)
        {
            Country = country;
            Name = name;
            Temp = temp;
            Description = description;
        }

        public override string ToString()
        {
            return $"Страна: {Country}, название местности: {Name}, температура воздуха: {Temp}°C, описание погоды: {Description}";
        }
    }

    public class City
    {
        public string Name { get; set; }
        public double Lat { get; set; }
        public double Lon { get; set; }

        public City(string name, double lat, double lon)
        {
            Name = name;
            Lat = lat;
            Lon = lon;
        }
    }
    public partial class Form1 : Form
    {
        private static readonly HttpClient client = new HttpClient();
        private const string apiKey = "c0bca192b2e8c99548078dfb57a5150c"; // Замените на ваш API-токен
        private List<City> cities;
        private ListBox cityListBox;
        private Label weatherLabel;
        private Button getWeatherButton;

        public Form1()
        {
            InitializeComponent();

        }

        private async void GetWeatherButton_Click(object sender, EventArgs e)
        {
            // Получение выбранного города из ListBox
            string selectedCityName = cityListBox.SelectedItem?.ToString();
            if (selectedCityName != null)
            {
                // Поиск города по имени
                City selectedCity = cities.FirstOrDefault(c => c.Name == selectedCityName);
                if (selectedCity != null)
                {
                    // Загрузка погоды асинхронно
                    Weather? weather = await GetWeatherAsync(selectedCity.Lat, selectedCity.Lon);
                    if (weather != null)
                    {
                        // Обновление текста Label с результатом
                        weatherLabel.Text = weather.Value.ToString();
                    }
                    else
                    {
                        weatherLabel.Text = "Не удалось получить данные о погоде.";
                    }
                }
                else
                {
                    weatherLabel.Text = "Город не найден.";
                }
            }
            else
            {
                weatherLabel.Text = "Выберите город.";
            }
        }
        private static async Task<Weather?> GetWeatherAsync(double lat, double lon)
        {
            try
            {
                var response = await client.GetStringAsync($"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&appid={apiKey}");
                dynamic json = JsonConvert.DeserializeObject(response);

                if (json.sys.country != null)
                {
                    return new Weather
                    {
                        Country = json.sys.country,
                        Name = json.name,
                        Temp = json.main.temp,
                        Description = json.weather[0].description
                    };
                }
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении данных о погоде: {ex.Message}");
                return null;
            }
        }
        

       
        private List<City> LoadCitiesFromFile(string filename)
        {
            List<City> cities = new List<City>();
            try
            {
                // Чтение данных из файла
                string[] lines = File.ReadAllLines(filename);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 3)
                    {
                        cities.Add(new City(parts[0], double.Parse(parts[1]), double.Parse(parts[2])));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке списка городов: {ex.Message}");
            }
            return cities;
        }
    }
    }
    