﻿using System;

public class MyMatrix
{
    private int[,] _matrix;
    private int _rows;
    private int _cols;

    public MyMatrix(int rows, int cols, int min, int max)
    {
        _rows = rows;
        _cols = cols;
        _matrix = new int[rows, cols];

        Random random = new Random();
        for (int i = 0; i < _rows; i++)
        {
            for (int j = 0; j < _cols; j++)
            {
                _matrix[i, j] = random.Next(min, max + 1);
            }
        }
    }

    public void Fill(int min, int max)
    {
        Random random = new Random();
        for (int i = 0; i < _rows; i++)
        {
            for (int j = 0; j < _cols; j++)
            {
                _matrix[i, j] = random.Next(min, max + 1);
            }
        }
    }

    public void ChangeSize(int newRows, int newCols, int min, int max)
    {
        int[,] newMatrix = new int[newRows, newCols];

        for (int i = 0; i < Math.Min(_rows, newRows); i++)
        {
            for (int j = 0; j < Math.Min(_cols, newCols); j++)
            {
                newMatrix[i, j] = _matrix[i, j];
            }
        }

        Random random = new Random();
        for (int i = 0; i < newRows; i++)
        {
            for (int j = 0; j < newCols; j++)
            {
                if (i >= _rows || j >= _cols)
                {
                    newMatrix[i, j] = random.Next(min, max + 1);
                }
            }
        }

        _matrix = newMatrix;
        _rows = newRows;
        _cols = newCols;
    }

    public void ShowPartialy(int startRow, int endRow, int startCol, int endCol)
    {
        for (int i = startRow; i <= endRow; i++)
        {
            for (int j = startCol; j <= endCol; j++)
            {
                Console.Write(_matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    public void Show()
    {
        for (int i = 0; i < _rows; i++)
        {
            for (int j = 0; j < _cols; j++)
            {
                Console.Write(_matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }

    public int this[int index1, int index2]
    {
        get
        {
            return _matrix[index1, index2];
        }
        set
        {
            _matrix[index1, index2] = value;
        }
    }

    public static void Main(string[] args)
    {
        Console.Write("Введите число строк: ");
        int rows = int.Parse(Console.ReadLine());

        Console.Write("Введите число столбцов: ");
        int cols = int.Parse(Console.ReadLine());

        Console.Write("Введите минимальное значение: ");
        int min = int.Parse(Console.ReadLine());

        Console.Write("Введите максимальное значение: ");
        int max = int.Parse(Console.ReadLine());

        MyMatrix matrix = new MyMatrix(rows, cols, min, max);

        Console.WriteLine("\nИсходная матрица:");
        matrix.Show();

        matrix.Fill(0, 10);
        Console.WriteLine("\nМатрица после Fill:");
        matrix.Show();

        matrix.ChangeSize(5, 7, 1, 10);
        Console.WriteLine("\nМатрица после ChangeSize:");
        matrix.Show();

        Console.WriteLine("\nЧастичный вывод матрицы:");
        matrix.ShowPartialy(1, 3, 2, 5);

        Console.WriteLine("\nИзменение элемента матрицы:");
        matrix[2, 3] = 50;
        matrix.Show();

        Console.ReadKey();
    }
}