﻿using System;

public class MyList<T>
{
    private T[] _items;
    private int _count;

    public MyList()
    {
        _items = new T[4]; 
        _count = 0;
    }

    public int Count => _count;

    public void Add(T item)
    {
        if (_count == _items.Length)
        {
            Resize();
        }
        _items[_count++] = item;
    }

    public T this[int index]
    {
        get
        {
            if (index < 0 || index >= _count)
            {
                throw new IndexOutOfRangeException("Индекс вне диапазона.");
            }
            return _items[index];
        }
        set
        {
            if (index < 0 || index >= _count)
            {
                throw new IndexOutOfRangeException("Индекс вне диапазона.");
            }
            _items[index] = value;
        }
    }

    private void Resize()
    {
        int newSize = _items.Length * 2;
        T[] newArray = new T[newSize];
        Array.Copy(_items, newArray, _count);
        _items = newArray;
    }
}


public class Program
{
    public static void Main()
    {
        MyList<int> myList = new MyList<int>();

        myList.Add(1);
        myList.Add(2);
        myList.Add(3);
        myList.Add(4);

        Console.WriteLine(myList[0]); 
        Console.WriteLine(myList[1]); 

        Console.WriteLine(myList.Count); 


        myList[1] = 20;
        Console.WriteLine(myList[1]); 
    }
}
