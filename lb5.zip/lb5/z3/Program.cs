﻿using System;

public class MyDictionary<TKey, TValue>
{
    private TKey[] _keys;
    private TValue[] _values;
    private int _count;

    public MyDictionary()
    {
        _keys = new TKey[4];
        _values = new TValue[4]; 
        _count = 0;
    }

    public int Count => _count;

    public void Add(TKey key, TValue value)
    {
        if (_count == _keys.Length)
        {
            Resize();
        }

        for (int i = 0; i < _count; i++)
        {
            if (_keys[i].Equals(key))
            {
                throw new ArgumentException("Ключ уже существует.");
            }
        }

        _keys[_count] = key;
        _values[_count] = value;
        _count++;
    }

    public TValue this[TKey key]
    {
        get
        {
            for (int i = 0; i < _count; i++)
            {
                if (_keys[i].Equals(key))
                {
                    return _values[i];
                }
            }
            throw new KeyNotFoundException("Ключ не найден.");
        }
    }

    private void Resize()
    {
        int newSize = _keys.Length * 2;
        TKey[] newKeys = new TKey[newSize];
        TValue[] newValues = new TValue[newSize];

        Array.Copy(_keys, newKeys, _count);
        Array.Copy(_values, newValues, _count);

        _keys = newKeys;
        _values = newValues;
    }

    public Enumerator GetEnumerator() => new Enumerator(this);

    public struct Enumerator
    {
        private MyDictionary<TKey, TValue> _dictionary;
        private int _index;

        public Enumerator(MyDictionary<TKey, TValue> dictionary)
        {
            _dictionary = dictionary;
            _index = -1;
        }

        public KeyValuePair<TKey, TValue> Current =>
            new KeyValuePair<TKey, TValue>(_dictionary._keys[_index], _dictionary._values[_index]);

        public bool MoveNext()
        {
            _index++;
            return (_index < _dictionary.Count);
        }
    }
}

public struct KeyValuePair<TKey, TValue>
{
    public TKey Key { get; }
    public TValue Value { get; }

    public KeyValuePair(TKey key, TValue value)
    {
        Key = key;
        Value = value;
    }
}


public class Program
{
    public static void Main()
    {
        MyDictionary<string, int> myDict = new MyDictionary<string, int>();

        myDict.Add("one", 1);
        myDict.Add("two", 2);

        Console.WriteLine(myDict["one"]); // 1
        Console.WriteLine(myDict.Count); // 2

        // Перебор элементов
        foreach (var kvp in myDict)
        {
            Console.WriteLine($"Ключ: {kvp.Key}, Значение: {kvp.Value}");
        }
    }
}
