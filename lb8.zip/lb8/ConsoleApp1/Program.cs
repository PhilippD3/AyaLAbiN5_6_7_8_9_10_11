﻿using lb8;
using System;
using System.IO;
using System.Xml.Serialization;

class Program
{
    static void Main(string[] args)
    {
        //Создание экземпляра класса Animal
        Animal animal = new Lion("Россия", false, "lion");

        string filePath = "animal.xml";

        ////        // Сериализация
        //XmlSerializer serializer = new XmlSerializer(typeof(Lion));
        //using (FileStream fs = new FileStream(filePath, FileMode.Create))
        //{
        //    serializer.Serialize(fs, animal);
        //}

        //Console.WriteLine("Объект Animal сериализован в файл " + filePath);

        // Десериализация
        Animal deserializedAnimal;
        XmlSerializer serializer = new XmlSerializer(typeof(Lion));
        using (FileStream fs = new FileStream(filePath, FileMode.Open))
        {
            deserializedAnimal = (Lion)serializer.Deserialize(fs);
        }

        //Вывод результата на консоль
        Console.WriteLine($"Страна: {deserializedAnimal.Country}");
        Console.WriteLine($"Прячут ли от других животных: {deserializedAnimal.HideFromOtherAnimals}");
        Console.WriteLine($"Имя: {deserializedAnimal.Name}");
    }
}