﻿using System;
using System.IO;
using System.Xml.Serialization;
using lb8;
class Program
{
    static void Main(string[] args)
    {
        // Десериализация
        Animal deserializedAnimal;
        XmlSerializer serializer = new XmlSerializer(typeof(Animal));
        using (FileStream fs = new FileStream("animal.xml", FileMode.Open))
        {
            deserializedAnimal = (Animal)serializer.Deserialize(fs);
        }

        // Вывод результата на консоль
        Console.WriteLine($"Имя: {deserializedAnimal.Name}");
        Console.WriteLine($"Страна: {deserializedAnimal.Country}");
        Console.WriteLine($"Скрывается от других животных: {deserializedAnimal.HideFromOtherAnimals}");
        Console.WriteLine($"Тип животного: {deserializedAnimal.WhatAnimal}");
        Console.WriteLine($"Изучаемая еда: {deserializedAnimal.GetFavoriteFood()}");
        Console.WriteLine($"Приветствие: {deserializedAnimal.SayHello()}");
    }
}