﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace lb8
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class CommentAttribute : Attribute
    {
        public string Comment { get; set; }

        public CommentAttribute(string comment)
        {
            Comment = comment;
        }
    }

    public enum eClassificationAnimal
    {
        Herbivores,
        Carnivores,
        Omnivores
    }

    public enum eFavoriteFood
    {
        Meat,
        Plants,
        Everything
    }

    [Comment("Базовый класс для всех животных")]
    [XmlInclude(typeof(Cow))]
    [XmlInclude(typeof(Lion))]
    [XmlInclude(typeof(Pig))]
    [XmlRoot("Animal")]
    public abstract class Animal
    {
        [XmlElement("Classification")]
        public eClassificationAnimal Classification { get; set; }

        [XmlElement("Country")]
        public string Country { get; set; }

        [XmlElement("HideFromOtherAnimals")]
        public bool HideFromOtherAnimals { get; set; }

        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("WhatAnimal")]
        public string WhatAnimal { get; set; }

        public Animal() { } // Конструктор для сериализации

        public Animal(string country, bool hideFromOtherAnimals, string name, string whatAnimal)
        {
            Country = country;
            HideFromOtherAnimals = hideFromOtherAnimals;
            Name = name;
            WhatAnimal = whatAnimal;
        }

        public void Deconstruct(out string country, out bool hideFromOtherAnimals, out string name, out string whatAnimal)
        {
            country = Country;
            hideFromOtherAnimals = HideFromOtherAnimals;
            name = Name;
            whatAnimal = WhatAnimal;
        }

        public virtual string GetClasificationAnimal()
        {
            return "Животное";
        }

        public virtual string GetFavoriteFood()
        {
            return "Трава";
        }

        public virtual string SayHello()
        {
            return "Привет!";
        }
    }

    [Comment("Базовый класс для коровы")]
    [XmlRoot("Cow")]
    public class Cow : Animal
    {
        public Cow() { } // Конструктор для сериализации

        public Cow(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Корова")
        {
        }

        public override string GetFavoriteFood()
        {
            return "Трава";
        }

        public override string SayHello()
        {
            return "Мууу!";
        }
    }

    [Comment("Базовый класс для льва")]
    [XmlRoot("Lion")]
    public class Lion : Animal
    {
        public Lion() { } // Конструктор для сериализации

        public Lion(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Лев")
        {
        }

        public override string GetFavoriteFood()
        {
            return "Мясо";
        }

        public override string SayHello()
        {
            return "Рррр!";
        }
    }

    [Comment("Базовый класс для свиньи")]
    [XmlRoot("Pig")]
    public class Pig : Animal
    {
        public Pig() { } // Конструктор для сериализации

        public Pig(string country, bool hideFromOtherAnimals, string name) : base(country, hideFromOtherAnimals, name, "Свинья")
        {
        }

        public override string GetFavoriteFood()
        {
            return "Корм";
        }

        public override string SayHello()
        {
            return "Хрю-хрю!";
        }
    }
}