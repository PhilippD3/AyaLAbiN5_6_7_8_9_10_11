﻿using System;
using System.IO;
using System.IO.Compression;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите путь к директории: ");
        string directoryPath = Console.ReadLine();

        Console.Write("Введите имя файла для поиска: ");
        string fileName = Console.ReadLine();

        string[] foundFiles = Directory.GetFiles(directoryPath, fileName, SearchOption.AllDirectories);

        if (foundFiles.Length == 0)
        {
            Console.WriteLine("Файл не найден.");
        }
        else
        {
            foreach (var filePath in foundFiles)
            {
                Console.WriteLine($"Найден файл: {filePath}");

                try
                {
                    Console.WriteLine("Содержимое файла:");
                    using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    {
                        using (StreamReader reader = new StreamReader(fs))
                        {
                            string content = reader.ReadToEnd();
                            Console.WriteLine(content);
                        }
                    }

                    string compressedFilePath = filePath + ".gz";
                    using (FileStream originalFileStream = new FileStream(filePath, FileMode.Open))
                    {
                        using (FileStream compressedFileStream = File.Create(compressedFilePath))
                        {
                            using (GZipStream compressionStream = new GZipStream(compressedFileStream, CompressionMode.Compress))
                            {
                                originalFileStream.CopyTo(compressionStream);
                            }
                        }
                    }

                    Console.WriteLine($"Файл сжат и сохранен как: {compressedFilePath}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
                }
            }
        }

        Console.WriteLine("Нажмите любую клавишу, чтобы выйти.");
        Console.ReadKey();
    }
}